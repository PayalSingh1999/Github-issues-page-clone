import React from 'react'

const Code = () => {
  return (
    <div>Code</div>
  )
}

export default Code