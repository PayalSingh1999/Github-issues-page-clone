import React from 'react'

const PullRequest = () => {
  return (
    <div>PullRequest</div>
  )
}

export default PullRequest